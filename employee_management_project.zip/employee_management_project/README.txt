Go in project's folder there your manage.py file exists, then run following command,

python manage.py runserver

it will start server at localhost 8000 port, give this address in crome browser, 

http://127.0.0.1:8000/